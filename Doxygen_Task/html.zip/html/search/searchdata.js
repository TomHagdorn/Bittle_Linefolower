var indexSectionsWithContent =
{
  0: "p",
  1: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Pages"
};

